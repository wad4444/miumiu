# @rbxts/pepecs

roblox-ts typings for [pepecs](https://github.com/PepeElToro41/pepecs) — an archetype ECS for Luau, heavily inspired by [jecs](https://github.com/ukendio/jecs). The package vendors the pepecs Luau source (`src/init.luau`, v0.0.9) verbatim and adds TypeScript declarations modeled after the jecs typings.

## Install

```sh
npm install @rbxts/pepecs
```

## Call conventions

pepecs differs from jecs in one important way: **world functions are closures**, called with `.` in Luau. The declarations encode this, so roblox-ts emits the right thing automatically:

- `World` members are function properties → `world.entity()`, `world.set(...)` (dot calls)
- `Query` members are metatable methods → `query:with(...)`, `query:iter()` (colon calls)
- `Monitor` / `QueryChanged` members are function properties → dot calls

## Usage

```ts
import * as ecs from "@rbxts/pepecs";
import { pair, ChildOf, Name } from "@rbxts/pepecs";

const world = ecs.world();

const Position = world.component<Vector3>();
const Velocity = world.component<Vector3>();
const Poisoned = world.tag();

const enemy = world.entity();
world.set(enemy, Position, new Vector3(0, 5, 0));
world.set(enemy, Velocity, Vector3.zero);
world.add(enemy, Poisoned);
world.set(enemy, Name, "enemy");

for (const [entity, position, velocity] of world.query(Position, Velocity)) {
	world.set(entity, Position, position.add(velocity));
}

// relationships
const parent = world.entity();
world.add(enemy, pair(ChildOf, parent));
print(world.parent(enemy) === parent); // true

// hooks
const disconnect = world.changed(Position, (entity, id, value) => {
	print("moved to", value);
});

// change tracking
const query = world.query(Position);
const tracker = query.changed();
// later, each frame:
for (const [entity, position] of tracker) {
	// only entities whose Position changed since the last drain
}
```

Preregistration (before any world exists) is also typed:

```ts
const Health = ecs.component<number>();
const MaxHealth = ecs.component<number>();
ecs.added(Health, (world, entity, id, value) => {});

const world = ecs.world(); // Health/MaxHealth registered automatically
```

## License

MIT — pepecs is by [PepeElToro41](https://github.com/PepeElToro41); see [LICENSE](LICENSE).

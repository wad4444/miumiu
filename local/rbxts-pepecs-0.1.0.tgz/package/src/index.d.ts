/**
 * TypeScript (roblox-ts) type definitions for pepecs
 * https://github.com/PepeElToro41/pepecs
 *
 * Modeled after the jecs type definitions (https://github.com/ukendio/jecs),
 * adapted to pepecs' API:
 * - `World` functions are closures and must be called with `.` (typed here as
 *   function properties, so roblox-ts emits dot calls).
 * - `Query` methods live on a metatable and are called with `:` (typed here as
 *   methods, so roblox-ts emits colon calls).
 */

/**
 * A unique identifier in the world, entity.
 * The generic type T defines the data type when this entity is used as a component.
 */
export type Entity<TData = unknown> = number & {
	readonly __nominal_Entity: unique symbol;
	readonly __type_TData: TData;
};

type TagDiscriminator = {
	readonly __nominal_Tag: unique symbol;
};

/**
 * An entity with no associated data when used as a component.
 */
export type Tag = Entity<TagDiscriminator>;

/**
 * A component entity. Alias of `Entity<TData>`, kept for parity with the
 * pepecs Luau `Component<T>` export.
 */
export type Component<TData = unknown> = Entity<TData>;

/**
 * A pair of entities:
 * - `R` is the type of the "relation" (first) entity.
 * - `T` is the type of the "target" (second) entity.
 */
export type Pair<R = unknown, T = unknown> = number & {
	readonly __nominal_Pair: unique symbol;
	readonly __relation: R;
	readonly __target: T;
};

/**
 * An `Id` is either a single Entity or a Pair of entities.
 * By providing `TData`, you can specifically require an Id that yields that type.
 */
export type Id<TData = unknown> = Entity<TData> | Pair<TData, unknown> | Pair<TagDiscriminator, TData>;

/**
 * Extracts the data type an `Id` stores.
 * For pairs the relation's type wins, unless the relation is a tag, in which
 * case the target's type is used (flecs/jecs semantics, which pepecs follows).
 */
export type InferComponent<E> = E extends Entity<infer D>
	? D
	: E extends Pair<infer R, infer T>
		? R extends TagDiscriminator
			? T
			: R
		: never;

type FlattenTuple<T extends unknown[]> = T extends [infer U] ? U : LuaTuple<T>;
type Nullable<T extends unknown[]> = { [K in keyof T]: T[K] | undefined };
export type InferComponents<A extends Id[]> = { [K in keyof A]: InferComponent<A[K]> };
type TagToUndefined<T> = T extends TagDiscriminator ? undefined : T;

type Cleanup = () => void;
type ArchetypeId = number;

export type Column<T = unknown> = T[];
type Columns<T extends Id[]> = { [K in keyof T]: Column<InferComponent<T[K]>> };

export type Archetype<T extends Id[] = Id[]> = {
	archetype_id: ArchetypeId;
	hash: string;
	/** Holds at least one entity. */
	alive: boolean;
	/** Removed from the world; must never be reused. */
	destroyed: boolean;

	entities: Entity[];
	columns: Column[];
	components: Id[];

	columns_map: { [K in T[number]]: Column<InferComponent<K>> };
	/** (R, *) wildcard id -> the single (R, T) pair held, for every exclusive relation R. */
	exclusive_pairs: Map<Id, Pair>;
	forward_edges: Map<Id, Archetype>;
	backwards_edges: Map<Id, Archetype>;
	swapped_edges: Map<Id, Id>;

	traversable_count: number;
	traversable_ids: Id[];
};

export type EntityRecord = {
	archetype: Archetype;
	archetype_row: number;
	dense: number;
	deleting: boolean;

	archetype_changed?: Array<(source: Archetype, destination: Archetype) => void>;
};

export type EntityIndex = {
	dense: Entity[];
	sparse: Map<number, EntityRecord>;
	alive: number;
};

export type ComponentRecord = {
	/** archetype id -> column index of this id inside that archetype. */
	column_index: Map<ArchetypeId, number>;
	/** Dense list of every archetype id holding this id. */
	archetype_ids: ArchetypeId[];
	flags: number;
};

export type PairRecord = ComponentRecord & {
	pairs_count: Map<ArchetypeId, number>;

	/** all records that share the same relation: (R, *) */
	first_records: Map<Id, PairRecord>;
	/** all records that share the same target: (*, T) */
	second_records: Map<Id, PairRecord>;
	/** all records with a traversable relation that share the same target */
	trav_records: Map<Id, PairRecord>;
};

export type ArchetypeMatch = (archetype: Archetype) => boolean;

export interface WorldInternal {
	entity_index: EntityIndex;
	component_record_ensure: (id: Id) => ComponentRecord;

	get_entity_any: (entity_id: number) => Entity | undefined;
	get_entity_alive: (entity_id: number) => Entity | undefined;

	get_entity_record: (entity: Entity) => EntityRecord | undefined;
	get_entity_record_alive: (entity: Entity) => EntityRecord | undefined;
	get_entity_record_asserts_alive: (entity: Entity) => EntityRecord | undefined;
}

/**
 * Hook fired when a component value is added or changed.
 */
export type SetHook<T = unknown> = (entity: Entity, id: Id<T>, value: T) => void;

/**
 * Hook fired when a component is removed. May return a callback that runs
 * after the removal has been applied.
 */
export type RemovedHook<T = unknown> = (entity: Entity, id: Id<T>) => Cleanup | void;

export interface Monitor {
	cleanup: Cleanup;
	added: (callback: (entity: Entity) => void) => void;
	removed: (callback: (entity: Entity) => void) => void;
}

type IterFn<T extends Id[]> = IterableFunction<LuaTuple<[Entity, ...InferComponents<T>]>>;
type Iter<T extends Id[]> = IterFn<T> & {
	/**
	 * This isn't callable, it only makes the object directly iterable.
	 * @hidden
	 * @deprecated
	 */
	(): never;
};

/**
 * Drained iterator over entities whose queried component values changed since
 * the previous drain. Iterate it directly or via `iter()`; call `cleanup()`
 * when no longer needed.
 */
export type QueryChanged<T extends Id[]> = {
	iter: () => IterFn<T>;
	cleanup: Cleanup;
} & Iter<T>;

export type Query<T extends Id[]> = {
	readonly is_cached: boolean;

	/**
	 * Adds ids the entity must have, without retrieving their values.
	 * Mutates and returns the same query.
	 */
	with(...ids: Id[]): Query<T>;

	/**
	 * Adds ids the entity must NOT have.
	 * Mutates and returns the same query.
	 */
	without(...ids: Id[]): Query<T>;

	/**
	 * Returns an uncached copy of this query with the same terms.
	 */
	clone(): Query<T>;

	/**
	 * Re-resolves and returns the matched archetypes.
	 */
	rematch(): Archetype<T>[];

	/**
	 * Returns the matched archetypes of the query.
	 */
	archetypes(): Archetype<T>[];

	/**
	 * Returns an iterator that yields each matched archetype together with its
	 * component columns, for direct column access.
	 */
	columns(): IterableFunction<LuaTuple<[Archetype<T>, ...Columns<T>]>>;

	/**
	 * Returns whether the archetype matches the query terms.
	 */
	match(archetype: Archetype): boolean;

	/**
	 * Returns whether the entity matches the query.
	 */
	has(entity: Entity): boolean;

	/**
	 * Returns whether the query matches no entities.
	 */
	empty(): boolean;

	/**
	 * Returns the number of entities matching the query.
	 */
	count(): number;

	/**
	 * Returns all entities matching the query.
	 */
	entities(): Entity[];

	/**
	 * Returns a random entity matching the query, if any.
	 */
	random(): Entity | undefined;

	/**
	 * Returns the first matching entity and its values, optionally the first
	 * one accepted by the predicate. Returns undefined(s) when nothing matches.
	 */
	first(
		predicate?: (entity: Entity, ...values: InferComponents<T>) => boolean,
	): FlattenTuple<[Entity | undefined, ...Nullable<InferComponents<T>>]>;

	/**
	 * Caches the matched archetypes, keeping them up to date as archetypes are
	 * created and destroyed. Mutates and returns the same query.
	 */
	cached(): Query<T>;

	/**
	 * Releases the archetype cache created by `cached()`.
	 */
	cleanup(): void;

	/**
	 * Returns an iterator producing tuples of [Entity, ...queriedValues].
	 */
	iter(): IterFn<T>;

	/**
	 * Replaces the queried component values of every matched entity with the
	 * values returned by the mapper.
	 */
	patch(mapper: (entity: Entity, ...values: InferComponents<T>) => FlattenTuple<InferComponents<T>>): void;

	/**
	 * Creates a monitor firing when entities start or stop matching the query.
	 */
	monitor(): Monitor;

	/**
	 * Observes the query: the callback fires when an entity starts matching or
	 * a queried component value changes. Returns a cleanup function.
	 */
	observe(callback: (entity: Entity) => void): Cleanup;

	/**
	 * Creates a change tracker over the queried components.
	 */
	changed(): QueryChanged<T>;
} & Iter<T>;

/**
 * A `"$name"` variable of the query engine. `"$this"` is the matched entity.
 */
export type QueryVariable = `${string}`;

/**
 * Builds a query for the query engine (`world.query_build()`). Each term call
 * starts a term; the modifiers after it (`optional`, `bor`, `wildcard`,
 * `target`, `from`, `up`, `self`, `transitive`) apply to that term.
 */
export interface QueryBuilder {
	/** Adds a term whose value is yielded by the query. */
	term(id: Id): QueryBuilder;
	/** Adds a term the entity must match, without yielding its value. */
	with(id: Id): QueryBuilder;
	/** Adds a term the entity must NOT match. */
	without(id: Id): QueryBuilder;
	/** Makes the pending term optional: it yields undefined when absent. */
	optional(): QueryBuilder;
	/** Joins the pending term with the next one: either may match. */
	bor(): QueryBuilder;
	/** Matches the pending term as `pair(term, Wildcard)`. */
	wildcard(): QueryBuilder;
	/** Matches the pending term as `pair(term, target)`; a variable binds the target. */
	target(target: Id | QueryVariable): QueryBuilder;
	/** Evaluates the pending term on the entity bound to the variable. */
	from(source: QueryVariable): QueryBuilder;
	/** Also matches the pending term on entities reached by walking the relation up. */
	up(relation: Id): QueryBuilder;
	/** Matches the pending term on the entity itself only. */
	self(): QueryBuilder;
	/** Walks the pending pair's relation transitively (exclusive relations). */
	transitive(): QueryBuilder;
	/** Compiles the query. */
	build(): EngineQuery;
}

/**
 * Query produced by `QueryBuilder.build()`. Yields the entity followed by the
 * values of its `term`s, in order.
 */
export type EngineQuery = {
	readonly is_cached: boolean;
	iter(): IterableFunction<LuaTuple<[Entity, ...unknown[]]>>;
	archetypes(): Archetype[];
	match(archetype: Archetype): boolean;
	rematch(): Archetype[];
	/** Caches the matched archetypes. Mutates and returns the same query. */
	cached(): EngineQuery;
	cleanup(): void;
	/** Returns the entity bound to the variable in the current iteration. */
	var(name: QueryVariable): Entity | undefined;
	monitor(): Monitor;
} & IterableFunction<LuaTuple<[Entity, ...unknown[]]>>;

/**
 * A cached query. In pepecs `cached()` mutates and returns the same query
 * object; the alias exists for tooling parity with the jecs typings.
 */
export type CachedQuery<T extends Id[]> = Query<T>;

/**
 * A pepecs world. All functions are closures: call them with `.`
 * (`world.entity()`), which is what these property types compile to.
 */
export interface World {
	components_lookup: Map<Id, ComponentRecord>;
	archetypes_lookup: Map<string, Archetype>;
	archetypes: Map<ArchetypeId, Archetype>;
	ROOT_ARCHETYPE: Archetype;
	internal: WorldInternal;

	/**
	 * Creates an entity in the component id range (fast access), with no data.
	 */
	tag: () => Tag;

	/**
	 * Creates a component entity in the component id range whose value type is `TData`.
	 */
	component: <TData = unknown>() => Entity<TData>;

	/**
	 * Creates a new entity.
	 */
	entity: () => Tag;

	/**
	 * Returns whether any entity with this id exists, dead or alive, ignoring generation.
	 */
	exists: (entity: Entity) => boolean;

	/**
	 * Returns whether the entity is alive.
	 */
	alive: (entity: Entity) => boolean;

	/**
	 * Returns whether the entity is currently being deleted.
	 */
	deleting: (entity: Entity) => boolean;

	/**
	 * Returns whether the entity has the given id.
	 */
	has: (entity: Entity, id: Id) => boolean;

	/**
	 * Retrieves component values on an entity. Missing components yield undefined.
	 */
	get: <T extends [Id, ...Id[]]>(entity: Entity, ...ids: T) => FlattenTuple<Nullable<InferComponents<T>>>;

	/**
	 * Returns the parent of the entity (the target of its `ChildOf` pair), if any.
	 */
	parent: (child: Entity) => Entity | undefined;

	/**
	 * Returns an iterator over the children of the entity (entities with `pair(ChildOf, parent)`).
	 */
	children: (parent: Entity) => IterableFunction<Entity>;

	/**
	 * Returns the nth (0-based) target of the entity's pairs with the given relation.
	 */
	target: (entity: Entity, relation: Id, index?: number) => Entity | undefined;

	/**
	 * Walks the relation upwards from the entity until an entity holding `id`
	 * is found, returning that entity and its value.
	 */
	traverse: <T>(entity: Entity, relation: Id, id: Id<T>) => LuaTuple<[Entity | undefined, T | undefined]>;

	/**
	 * Returns an iterator over the entity's pair ids with the given relation.
	 */
	pairs: (entity: Entity, relation: Id) => IterableFunction<Pair>;

	/**
	 * Adds an id (tag or pair holding no data) to the entity.
	 */
	add: <C extends Id>(
		entity: Entity,
		id: TagDiscriminator extends InferComponent<C> ? C : Id<TagDiscriminator>,
	) => void;

	/**
	 * Sets the value of a component on the entity.
	 */
	set: <E extends Id>(entity: Entity, id: E, value: InferComponent<E>) => void;

	/**
	 * Removes an id from the entity.
	 */
	remove: (entity: Entity, id: Id) => void;

	/**
	 * Deletes the entity and cleans up its relationships.
	 */
	delete: (entity: Entity) => void;

	/**
	 * Removes the id from every entity that has it.
	 */
	wipe: (id: Id) => void;

	/**
	 * Removes all ids from the entity without deleting it.
	 */
	clear: (entity: Entity) => void;

	/**
	 * Adds multiple ids to the entity in a single archetype move.
	 */
	bulk_add: (entity: Entity, ids: Id[]) => void;

	/**
	 * Sets multiple component values on the entity in a single archetype move.
	 * Tags take undefined as their value.
	 */
	bulk_set: <const C extends Id[]>(
		entity: Entity,
		ids: C,
		values: { [K in keyof C]: TagToUndefined<InferComponent<C[K]>> },
	) => void;

	/**
	 * Removes multiple ids from the entity in a single archetype move.
	 */
	bulk_remove: (entity: Entity, ids: Id[]) => void;

	/**
	 * Registers a hook fired when the id is added to any entity. Returns a disconnect function.
	 */
	added: <I extends Id>(id: I, callback: (entity: Entity, id: I, value: InferComponent<I>) => void) => Cleanup;

	/**
	 * Registers a hook fired when the id's value changes on any entity. Returns a disconnect function.
	 */
	changed: <I extends Id>(id: I, callback: (entity: Entity, id: I, value: InferComponent<I>) => void) => Cleanup;

	/**
	 * Registers a hook fired when the id is removed from any entity. The hook
	 * may return a callback that runs after the removal. Returns a disconnect function.
	 */
	removed: <I extends Id>(id: I, callback: (entity: Entity, id: I) => Cleanup | void) => Cleanup;

	/**
	 * Returns the relation (first) entity of a pair.
	 */
	pair_first: <R>(pair: Pair<R, unknown>) => Entity<R>;

	/**
	 * Returns the target (second) entity of a pair.
	 */
	pair_second: <T>(pair: Pair<unknown, T>) => Entity<T>;

	/**
	 * Returns whether the id holds data.
	 */
	is_component: (id: Id) => boolean;

	/**
	 * Returns whether the id holds no data.
	 */
	is_tag: (id: Id) => boolean;

	/**
	 * Returns an iterator over every entity that has the id.
	 */
	each: (id: Id) => IterableFunction<Entity>;

	/**
	 * Creates a query over entities that have all the given ids.
	 */
	query: <T extends Id[]>(...ids: T) => Query<T>;

	/**
	 * Starts a query for the query engine: variables, optional/or terms,
	 * traversal (`up`, `transitive`) and sources.
	 */
	query_build: () => QueryBuilder;
}

/**
 * Creates a new world. Preregistered components, entities, metadata and hooks
 * are registered into it on creation.
 */
export declare function world(): World;

export declare const World: {
	new: () => World;
};

/**
 * Creates a pair id from a relation and a target.
 */
export declare function pair<R, T>(first: Id<R>, second: Id<T>): Pair<R, T>;

/**
 * Returns whether the id is a pair.
 */
export declare function is_pair(id: Id): id is Pair;

/**
 * Preregisters a component before any world exists. Every world created
 * afterwards registers it as a component.
 */
export declare function component<TData = unknown>(): Entity<TData>;

/**
 * Preregisters a tag before any world exists.
 */
export declare function tag(): Tag;

/**
 * Preregisters an entity before any world exists.
 */
export declare function entity(): Tag;

/**
 * Preregisters metadata: every world created afterwards sets (or adds, when
 * value is omitted) the id on the entity.
 */
export declare function meta<T>(entity: Entity, id: Id<T>, value?: T): void;

/**
 * Extracts the raw id (without generation) of a pair's relation.
 */
export declare function PAIR_FIRST(pair: Pair): number;

/**
 * Extracts the raw id (without generation) of a pair's target.
 */
export declare function PAIR_SECOND(pair: Pair): number;

export declare const Rest: Entity;
export declare const ChildOf: Tag;
export declare const Name: Entity<string>;
export declare const Exclusive: Tag;
export declare const OnDelete: Tag;
export declare const OnDeleteTarget: Tag;
export declare const Wildcard: Entity;
export declare const Delete: Tag;
export declare const ForceTag: Tag;
export declare const Error: Tag;
export declare const Traversable: Tag;
export declare const Transitive: Tag;
export declare const Disabled: Tag;
